package com.example.babycare.Fragment;

import androidx.fragment.app.Fragment;

public class SettingFragment extends Fragment {
}
