package com.example.babycare.Fragment;

import androidx.fragment.app.Fragment;

public class Tab1Fragment extends Fragment {
}
