package com.example.babycare.Fragment;

import androidx.fragment.app.Fragment;

public class Tab2Fragment extends Fragment {
}
